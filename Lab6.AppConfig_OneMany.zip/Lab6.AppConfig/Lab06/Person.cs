﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab06
{
    public class Person
    {
        public int PersonID { get; set; }
        public String Name { get; set; }
        public String Address { get; set; }
        public String Job { get; set; }
    }
}
